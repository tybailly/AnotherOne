
public class soccerPlayer extends Athlete {   // Child of Athlete 
	
	String position1;

	public soccerPlayer(String name, String team, String position, String position1, int age) {
		super(name, team, position, age);
		setPosition1(position1);

	}
	


public String getPosition1() {
		return position1;
	}



	public void setPosition1(String position1) {
		this.position1 = position1;
	}



public static void doThis() {    // ** Do this method
	System.out.println("I kick the ball");

}

public String toString(){
	String result;
	result = super.toString() + ". I play " + position1;
	return result;
	}


}
