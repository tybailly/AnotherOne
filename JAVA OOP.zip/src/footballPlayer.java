
public class footballPlayer extends Athlete {   // Child of Athlete
	
	String specialty;

	public footballPlayer(String name, String team, String position, String specialty, int age) {
		super(name, team, position, age);
     setSpecialty(specialty);
	}
	
	public String getSpecialty() {
		return specialty;
	}

	public void setSpecialty(String specialty) {
		this.specialty = specialty;
	}

	public static void doThis() {   // ** Do this method 
		System.out.println("I tackle something");

}
	public String toString() {
		String result;
		result = super.toString() + ". I play " + specialty;
		return result;
	}
}
