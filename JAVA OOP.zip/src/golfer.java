
public class golfer extends Athlete{  // Child of Athlete 
	
	String mainSponser;

	public golfer(String name, String team, String position, String mainSponser, int age) {
		super(name, team, position, age);
		setMainSponser(mainSponser);
	
	}
	
	public String getMainSponser() {
		return mainSponser;
	}

	public void setMainSponser(String mainSponser) {
		this.mainSponser = mainSponser;
	}

	public static void doThis() {  // Do this method 
		System.out.println("i putt it in the hole");

}
	public String toString() {
		String result;
		result = super.toString() + ". My main sponser is " + mainSponser;
		return result;
	}

}
