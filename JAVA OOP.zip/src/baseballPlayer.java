
public class baseballPlayer extends Athlete {  // Child of Athlete 
	
String battingPosition;

	public baseballPlayer(String name, String team, String position, String battingPosition, int age) {
		super(name, team, position, age);
		
		setBattingPosition(battingPosition);
		
	}
	
	public String getBattingPosition() {
		return battingPosition;
	}

	public void setBattingPosition(String battingPosition) {
		this.battingPosition = battingPosition;
	}

	public static void doThis() {   // ** doThis method 
		System.out.println("I hit something"); 
	}
	
	public String toString() {
		String result;
		result = super.toString() + ". My batting stance is: " + battingPosition;
		return result;
	}


}
