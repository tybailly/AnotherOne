// Name: Tyler Bailly    Date: 4/13/2020     Purpose: This program creates several sport classes, allowing somebody to enter in the info of whomever they may wish
                                                     // Also this program has a doThis method, which describes what that particular athlete may do in his or her sport

public class TEST {   // Test class to test output of classes

	public static void main(String[] args) {    // instances of classes created (some info may not be accurate)

		Person HockeyPlayerMario = new hockeyPlayer("Mario", "Pittsburg Penguins", "Forward", "CCM", 55);

		Person BaseballPlayerHank = new baseballPlayer("Hank", "Milwaukee Brewers", "Right Field", "Right", 40);

		Person FootballPlayerTerry = new footballPlayer("Terry", "Pittsburg Steelers", "QB", "Offense", 65);
		
		Person GolferPaula = new golfer("Paula", "Womens Golf", "Golf", "Nike", 33);
		
		Person SoccerPlayerDanilo = new soccerPlayer("Danilo", "Juventus", "Right Back", "Mid fielder", 28);
		
		Person BaseballPlayerBarry = new baseballPlayer("Barry", "Pittsburg Pirates", "Left Field", "Left", 55);
		
		Person FootballPlayerPeyton = new footballPlayer("Peyton", "Denver Broncos", "QB", "Offense", 44);
		
		Person HockeyPlayerWayne = new hockeyPlayer("Wayne", "New York Rangers", "Forward", "Easton", 59);
		
		Person GolferPhil = new golfer("Phil", "Mens Golf", "Golf", "Rolex", 49);
		
		Person SoccerPlayerCarlos = new soccerPlayer("Carols", "Delhi Dynamos", "Left Back", "Mid Field", 47);

		
		
		// OUTPUT of all classes along with doThis method 
		
		System.out.println(HockeyPlayerMario);
		hockeyPlayer.doThis();
		System.out.println("");
		
		System.out.println(BaseballPlayerHank);
		baseballPlayer.doThis();
		System.out.println("");
		
		System.out.println(FootballPlayerTerry);
		footballPlayer.doThis();
		System.out.println("");
		
		System.out.println(GolferPaula);
		golfer.doThis();
		System.out.println("");
		
		System.out.println(SoccerPlayerDanilo);
		soccerPlayer.doThis();
		System.out.println("");
		
		System.out.println(BaseballPlayerBarry);
		baseballPlayer.doThis();
		System.out.println("");
		
		System.out.println(FootballPlayerPeyton);
		footballPlayer.doThis();
		System.out.println("");
		
		System.out.println(HockeyPlayerWayne);
		hockeyPlayer.doThis();
		System.out.println("");
		
		System.out.println(GolferPhil);
		golfer.doThis();
		System.out.println("");
		
		System.out.println(SoccerPlayerCarlos);
		soccerPlayer.doThis();
		

		
		 // DoThis method called from each class
	}

	public static void doThisH(Person HockeyPlayer) {

	}

	public static void doThisB(Person baseballPlayer) {

	}
	public static void doThisF(Person footballPlayer) {

	}
	public static void doThisS(Person soccerPlayer) {

	}
	public static void doThisG(Person golfer) {

	}
	
	

}
