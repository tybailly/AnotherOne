
public class hockeyPlayer extends Athlete{  // Child of Athlete 
	
	String stickBrand;

	public hockeyPlayer(String name, String team, String position, String stickBrand, int age) {
		super(name, team, position, age);
		setStickBrand(stickBrand);

	}
	
	
	public String getStickBrand() {
		return stickBrand;
	}


	public void setStickBrand(String stickBrand) {
		this.stickBrand = stickBrand;
	}


	public static void doThis() { // ** Do this method
		System.out.println("I sit in a penalty box");

}
	
	public String toString(){
	String result;
	result = super.toString() + " and my brand hockey stick is: " + stickBrand;
	return result;
	}

}
