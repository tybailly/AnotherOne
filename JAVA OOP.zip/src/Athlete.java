
public class Athlete extends Person { // Parent of Sport classes, child of Parent

	String team, position;

	public Athlete(String name, String team, String position, int age) {
		super(name, age);
		setTeam(team);
		setPosition(position);

	}

	public String getTeam() {
		return team;
	}

	public void setTeam(String team) {
		this.team = team;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}
	
	public String toString() {
		String result;
		result = super.toString() + ". I play for the " + team + ", and my position is: " + position;
		return result;

}
}
